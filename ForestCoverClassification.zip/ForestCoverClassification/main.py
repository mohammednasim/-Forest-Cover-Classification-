from flask import Flask, render_template, request, redirect, url_for
from trainingModel import Trainer
from predictFormModel import Predictor

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/train', methods=['POST'])
def train_model():
    try:
        train_file = request.files['train_file']
        if train_file:
            file_path = f"./resourceForest/Training_Batch_Files/{train_file.filename}"
            train_file.save(file_path)
            trainer = Trainer()
            trainer.train(file_path)
            return render_template('train_result.html', message="Model trained successfully!")
    except Exception as e:
        return render_template('train_result.html', message=f"Error: {str(e)}")

@app.route('/predict', methods=['POST'])
def predict():
    try:
        predict_file = request.files['predict_file']
        if predict_file:
            file_path = f"./resourceForest/Prediction_Batch_files/{predict_file.filename}"
            predict_file.save(file_path)
            predictor = Predictor()
            result = predictor.predict(file_path)
            return render_template('prediction_result.html', result=result)
    except Exception as e:
        return render_template('prediction_result.html', result=f"Error: {str(e)}")

if __name__ == "__main__":
    app.run(debug=True)
