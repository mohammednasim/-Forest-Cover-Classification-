from sklearn.model_selection import GridSearchCV

class ModelTuner:
    def tune(self, model, params, X, y):
        grid_search = GridSearchCV(model, params, cv=5, n_jobs=-1)
        grid_search.fit(X, y)
        return grid_search.best_params_
