import pandas as pd
import pickle


class Predictor:
    def predict(self, input_data):
        # Load the trained model
        with open('model.pkl', 'rb') as model_file:
            model = pickle.load(model_file)

        # Load the expected feature columns
        with open('model_features.pkl', 'rb') as feature_file:
            expected_columns = pickle.load(feature_file)

        # Process input data
        input_df = pd.DataFrame([input_data])

        # One-hot encode categorical variables in input data
        input_df = pd.get_dummies(input_df)

        # Align input data columns with expected columns
        for col in expected_columns:
            if col not in input_df.columns:
                input_df[col] = 0  # Add missing columns with a value of 0

        # Ensure the order of columns matches
        input_df = input_df[expected_columns]

        # Make prediction
        prediction = model.predict(input_df)

        return prediction
