from sklearn.cluster import KMeans

class Clustering:
    def cluster(self, data):
        # Example clustering with KMeans
        kmeans = KMeans(n_clusters=3, random_state=42)
        clusters = kmeans.fit_predict(data)
        return clusters
