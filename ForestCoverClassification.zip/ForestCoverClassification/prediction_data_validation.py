class PredictionDataValidation:
    def __init__(self, required_columns):
        self.required_columns = required_columns

    def validate(self, data):
        # Check if all required columns are present in the data
        missing_columns = [col for col in self.required_columns if col not in data.columns]

        if missing_columns:
            raise ValueError(f"Missing columns: {', '.join(missing_columns)}")

        return True
