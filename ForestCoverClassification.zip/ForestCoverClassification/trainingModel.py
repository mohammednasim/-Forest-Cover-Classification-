import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import pickle


class Trainer:
    def train(self, file_path):
        # Load the data
        data = pd.read_csv(file_path, encoding='utf-8')

        # Strip any leading/trailing spaces in column names
        data.columns = data.columns.str.strip()

        # Check if 'Income' column exists after stripping spaces
        if 'Income' not in data.columns:
            raise ValueError("The 'Income' column is not found in the dataset.")

        # Handle missing or invalid entries
        data.replace(" ?", pd.NA, inplace=True)
        data.dropna(inplace=True)

        # Convert categorical variables into dummy/indicator variables
        data = pd.get_dummies(data)

        # Split the data into features and target variable
        X = data.drop('Income_ <=50K', axis=1)  # Change this depending on your specific encoding
        y = data['Income_ >50K']  # Assuming binary classification with >50K as the positive class

        # Split the dataset into training and test sets
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Initialize and train the model
        model = RandomForestClassifier()
        model.fit(X_train, y_train)

        # Save the model and the feature columns
        with open('model.pkl', 'wb') as model_file:
            pickle.dump(model, model_file)
        with open('model_features.pkl', 'wb') as feature_file:
            pickle.dump(X.columns.tolist(), feature_file)
